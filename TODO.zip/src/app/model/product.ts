export class Product {
  _id?: string;

  name?: string;

  quantity?: number;

  price?: number;

  description?: number;
}
