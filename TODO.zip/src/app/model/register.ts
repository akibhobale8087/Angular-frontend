export class Register {
  _id?: string;
  name?: string;
  email: string;
  password: string;

  contactnumber?: string;
  success?: boolean;

  error?: string;
}
